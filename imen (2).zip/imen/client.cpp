#include "client.h"
#include <QDebug>

#include "mainwindow.h"


Client::Client()
{
idClient ="";
nom="";
prenom="";
email="";
numero="";

}
Client::Client(QString idClient,QString nom,QString prenom ,QString email , QString numero)
{
  this->idClient=idClient;
  this->nom=nom;
  this->prenom=prenom;
  this->email=email;
  this->numero=numero ;

}

//ajouter

bool Client::ajouter(Client C)
{
    QSqlQuery query;

    query.prepare("INSERT INTO TABCLIENT (idClient, NOM, PRENOM, EMAIL, NUMERO) "
                        "VALUES (:idclient, :nom, :prenom, :email, :numero)");
    query.bindValue(":idclient",C.get_idClient());
    query.bindValue(":nom",C.get_nom());
    query.bindValue(":prenom",C.get_prenom());
    query.bindValue(":email",C.get_email());
    query.bindValue(":numero",C.get_num());
    return query.exec();
}



//afficher

QSqlQueryModel * Client::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from TABCLIENT");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("idClient"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prénom"));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("Email"));
model->setHeaderData(4, Qt::Horizontal, QObject::tr("Numero"));
    return model;
}

//supprimer

bool Client::supprimer(QString iddClient)
{
QSqlQuery query;
//QString idClient= QString::number(iddclient);
query.prepare("Delete from tabclient where idClient = :idClient ");
query.bindValue(":idClient",iddClient);
return    query.exec();
}
//modifier
bool Client::modifier(Client c)
{
    QSqlQuery query;

       query.prepare("UPDATE TABCLIENT SET NOM =:nom , PRENOM =:prenom , EMAIL =:email ,NUMERO =:numero WHERE idClient =:idclient ");
       query.bindValue(":idclient", c.get_idClient());
       query.bindValue(":nom", c.get_nom());
       query.bindValue(":prenom",c.get_prenom());
       query.bindValue(":email", c.get_email());
       query.bindValue(":numero", c.get_num());
    return query.exec();
}

//tri

QSqlQueryModel *Client::tri()
{
QSqlQuery *q = new QSqlQuery();
QSqlQueryModel *model = new QSqlQueryModel();
q->prepare("SELECT * FROM TABCLIENT ORDER BY NOM");
q->exec();
model->setQuery(*q);
return model;
}

//recherche

QSqlQueryModel *Client::recherchernomclient(QString nom)
{

QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("SELECT * FROM TABCLIENT WHERE NOM like '"+nom+"%' ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("idClient"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("Nom "));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Prénom"));
 model->setHeaderData(3, Qt::Horizontal, QObject::tr("Email"));
 model->setHeaderData(4, Qt::Horizontal, QObject::tr("Numero"));
return model;

}

QSqlQueryModel * Client::getIdModel()
{
    QSqlQuery *query = new QSqlQuery();
    QSqlQueryModel *model = new QSqlQueryModel();
    query->prepare("select idClient from TABCLIENT");
    query->exec();
    model->setQuery(*query);
    return model;
}

bool Client::verif_email(QString ch){
   bool test=false;
   int i;
   for(i=0;i<ch.length();i++)
   {
       if(ch[i]=='@'){
           test=true;
       }
   }
   return  test;
}


bool Client::verif_id(QString ch_id){
   bool test=true;
   int i;
   if(ch_id.length()!=8){
      test=false;
      return  test;
   }else{
       for(i=0;i<ch_id.length();i++){
           if(!((ch_id[i]>='0')&&(ch_id[i]<='9'))){
               test=false;
               return  test;
       }
       }
   }
return test;}
bool Client::verif_nom(QString nom){
    bool test=true;
    int i;
    if(nom.length()>20){
       test=false;
       return  test;
    }else{
        for(i=0;i<nom.length();i++){
            if(!(((nom[i]>='A')&&(nom[i]<='Z'))||((nom[i]>='a')&&(nom[i]<='z')))){
                test=false;
                return  test;
        }
    }
  }
    return  test;
}
