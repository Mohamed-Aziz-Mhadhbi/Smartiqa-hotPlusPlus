#include "servicech.h"
#include <QDebug>
#include "connection.h"
servicech::servicech()
{
ID_CH="";
type="";
ID_SER_CH="";

}
servicech::servicech(QString ID_SER_CH , QString type ,QString ID_CH)
{
  this->ID_CH=ID_CH;
  this->type=type;
  this->ID_SER_CH=ID_SER_CH;
}
QString servicech::get_IDCH(){return ID_CH;}
QString servicech::get_type(){return type;}
QString servicech::get_IDSERCH(){return ID_SER_CH;}


bool servicech::ajouter()
{
    QSqlQuery query;

    query.prepare("INSERT INTO SERVICE_CH (ID_CH ,ID_SER_CH ,TYPE ) "
                        "VALUES (:ID_CH, :ID_SER_CH, :type)");
query.bindValue(":ID_SER_CH", ID_SER_CH);
query.bindValue(":ID_CH", ID_CH);
query.bindValue(":type", type);



return    query.exec();
}

bool servicech::verif_IDSERCH(QString ID_SER_CH)
{
   bool test=true;
   int i;
   if(ID_SER_CH.length()==0){
      test=false;
      return  test;
   }else{
       for(i=0;i<ID_SER_CH.length();i++){
           if(!((ID_SER_CH[i]>='0')&&(ID_SER_CH[i]<='9'))){
               test=false;
               return  test;
       }
       }
   }
return test;}

QSqlQueryModel *servicech::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from service_ch ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("ID_SER_CH"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("TYPE"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("ID_CH "));
;
    return model;
}

bool servicech::supprimer(QString id_serv_chh)
{
QSqlQuery query;
QString res= QString(id_serv_chh);
query.prepare("Delete from chambre where ID_SER_CH = :id_ser_ch  ");
query.bindValue(":id_ser_ch", res);
return    query.exec();
}
