#ifndef CLIENT_H
#define CLIENT_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include"QPainter"
#include"QPdfWriter"
#include"QDesktopServices"
#include"QtPrintSupport/QPrinter"
#include <QPropertyAnimation>



class Client
{  public:
    Client() ;
    Client(QString ,QString ,QString,QString, QString);
    QString get_idClient( ){return idClient ;}
    QString get_num() {return numero ;}
    QString get_nom(){ return  nom;}
    QString get_prenom() {return prenom ;}
    QString get_email(){return  email ;}
    void initialiser();
    void setNom(QString);
    void setPrenom(QString);
    void setidClient(QString);
    void setNum(QString);
    void setEmail(QString);
    bool ajouter(Client c);
    bool modifier (Client c);
    bool supprimer(QString iddclient);
    QSqlQueryModel * afficher();
    QSqlQueryModel *recherchernomclient(QString);
    QSqlQueryModel *tri();
    QSqlQueryModel * getIdModel();
    bool verif_email(QString ch);
    bool verif_id(QString ch);
    bool verif_nom(QString ch);

    private:
    QString idClient ;
    QString numero ;

    QString nom , prenom , email ;
};

#endif // CLIENT_H

