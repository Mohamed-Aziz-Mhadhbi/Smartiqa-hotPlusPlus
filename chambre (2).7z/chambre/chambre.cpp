#include "chambre.h"
#include <QDebug>
#include "connection.h"
chambre::chambre()
{
num_ch="";
type="";

}
chambre::chambre(QString num_ch,QString type)
{
  this->num_ch=num_ch;
  this->type=type;

}
QString chambre::get_type(){return  type;}

QString chambre::get_numch(){return  num_ch;}

void chambre::set_type(QString type){this->type=type;};
void chambre::set_numch(QString num_ch){this->num_ch=num_ch;};


bool chambre::ajouter()
{
QSqlQuery query;

query.prepare("INSERT INTO chambre (NUM_CH, TYPE) "
                    "VALUES (:num_ch, :type)");
query.bindValue(":num_ch", num_ch);
query.bindValue(":type", type);


return    query.exec();
}

QSqlQueryModel *chambre::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from CHAMBRE");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("NUM_CH"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("TYPE"));

    return model;
}

bool chambre::supprimer(QString num_chh)
{
QSqlQuery query;
QString res= QString(num_chh);
query.prepare("Delete from chambre where NUM_CH = :num_ch ");
query.bindValue(":num_ch", res);
return    query.exec();
}
bool chambre::verif_num_ch(QString num_ch)
{
   bool test=true;
   int i;
   if(num_ch.length()==0){
      test=false;
      return  test;
   }else{
       for(i=0;i<num_ch.length();i++){
           if(!((num_ch[i]>='0')&&(num_ch[i]<='9'))){
               test=false;
               return  test;
       }
       }
   }

return test;}
bool chambre::modifier(chambre C)
{
    QSqlQuery query;

    query.prepare("UPDATE chambre set NUM_CH = :num_ch ,TYPE = :type where NUM_CH = :num_ch");

    query.bindValue(":num_ch ",C.get_numch());
    query.bindValue(":type",C.get_type());

    return    query.exec();
}
QSqlQueryModel *  chambre::rechercher(QSqlQuery q)
{
    QSqlQueryModel *model= new QSqlQueryModel();

    model->setQuery(q);
    return (model);
}
