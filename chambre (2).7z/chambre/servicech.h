#ifndef SERVICECH_H
#define SERVICECH_H
#include <qstring.h>
#include <QSqlDatabase>
#include <QSqlQueryModel>
#include <QSqlQuery>

class servicech
    {
    public:
        servicech();
        servicech(QString ,QString ,QString);
        QString get_IDCH();
        QString get_IDSERCH();
        QString get_type();
        bool ajouter();
        bool verif_IDSERCH(QString);
        QSqlQueryModel * afficher();
        bool supprimer(QString);
    private:
        QString ID_CH ;
        QString type ;
        QString ID_SER_CH ;

    };


#endif // SERVICECH_H
