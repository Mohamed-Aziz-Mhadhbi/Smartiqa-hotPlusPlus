#include "avis.h"
#include <QDebug>
#include "mainwindow.h"

Avis::Avis()
{
num ="";
idClient="";
dateavis="";
etat="";



}
Avis::Avis(QString num,QString idClient,QString dateavis ,QString etat)
{
  this->num=num;
  this->idClient=idClient;
  this->dateavis=dateavis;
  this->etat=etat;



}
//ajouter


bool Avis::ajouter(Avis a)
{
    QSqlQuery query;

    query.prepare("INSERT INTO TABAVIS (NUM, IDCLIENT, DATEAVIS,  ETAT) "
                        "VALUES (:num, :idClient, :dateavis, :etat)");
    query.bindValue(":num",a.get_num());
     query.bindValue(":idClient",a.get_idClient());
    query.bindValue(":dateavis",a.get_dateavis());
    query.bindValue(":etat",a.get_etat());


    return query.exec();
}
//afiicher

QSqlQueryModel * Avis::afficher()
{QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("select * from TABAVIS");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("Num"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("idClient"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Dateavis "));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("Etat"));


    return model;
}

//supprimer

bool Avis::supprimer(QString Numm)
{
QSqlQuery query;

query.prepare("Delete from TABAVIS where NUM= :NUM ");
query.bindValue(":NUM", Numm);
return    query.exec();
}
//modifier

bool Avis::modifier(Avis a)
{
    QSqlQuery query;

       query.prepare("UPDATE TABAVIS SET  IDCLIENT=:idClient ,DATEAVIS =:dateavis  ,ETAT =:etat  WHERE NUM =:num ");
       query.bindValue(":num",a.get_num());
       query.bindValue(":idClient",a.get_idClient());
       query.bindValue(":dateavis",a.get_dateavis());
       query.bindValue(":etat",a.get_etat());


    return query.exec();
}
//tri

QSqlQueryModel *Avis::tri()
{
QSqlQuery *q = new QSqlQuery();
QSqlQueryModel *model = new QSqlQueryModel();
q->prepare("SELECT * FROM TABAVIS ORDER BY NUM");
q->exec();
model->setQuery(*q);
return model;
}

//recherche


QSqlQueryModel *Avis::rechercher(QString num)
{


QSqlQueryModel * model= new QSqlQueryModel();

model->setQuery("SELECT * FROM TABAVIS WHERE NUM like '"+num+"%' ");
model->setHeaderData(0, Qt::Horizontal, QObject::tr("Num"));
model->setHeaderData(1, Qt::Horizontal, QObject::tr("idClient"));
model->setHeaderData(2, Qt::Horizontal, QObject::tr("Dateavis "));
model->setHeaderData(3, Qt::Horizontal, QObject::tr("Etat"));

return model;

}



bool Avis::verif_id(QString ch_id){
   bool test=true;
   int i;
   if(ch_id.length()!=8){
      test=false;
      return  test;
   }else{
       for(i=0;i<ch_id.length();i++){
           if(!((ch_id[i]>='0')&&(ch_id[i]<='9'))){
               test=false;
               return  test;
       }
       }
   }
return test;}
bool Avis::verif_nom(QString nom){
    bool test=true;
    int i;
    if(nom.length()>20){
       test=false;
       return  test;
    }else{
        for(i=0;i<nom.length();i++){
            if(!(((nom[i]>='A')&&(nom[i]<='Z'))||((nom[i]>='a')&&(nom[i]<='z')))){
                test=false;
                return  test;
        }
    }
  }
    return  test;
}
