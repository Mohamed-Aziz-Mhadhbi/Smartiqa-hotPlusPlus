#ifndef CHAMBRE_H
#define CHAMBRE_H
#include <qstring.h>
#include <QSqlDatabase>
#include <QSqlQueryModel>
#include <QSqlQuery>

class chambre
{
public:
    chambre();
    chambre(QString ,QString );

    QString get_numch();
    QString get_type();

    void set_numch(QString);
    void set_type(QString);
    bool ajouter();
    QSqlQueryModel * afficher();
    bool supprimer(QString);
    bool verif_num_ch(QString );
    bool modifier(chambre );
    QSqlQueryModel *  rechercher(QSqlQuery);
private:
    QString num_ch ;
    QString type ;

};

#endif // CHAMBRE_H
