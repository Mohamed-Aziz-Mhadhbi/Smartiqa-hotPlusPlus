#ifndef AVIS_H
#define AVIS_H
#include <QString>
#include <QSqlQuery>
#include <QSqlQueryModel>
#include"QPainter"
#include"QPdfWriter"
#include"QDesktopServices"
#include"QtPrintSupport/QPrinter"
#include <QPropertyAnimation>

class Avis
{  public:
    Avis() ;
    Avis(QString ,QString ,QString,QString);
    QString get_num( ){return num ;}
    QString get_idClient(){return  idClient ;}
    QString get_dateavis(){ return  dateavis;}
    QString get_etat() {return etat ;}


    void setnum(QString);
    void setidClient(QString);
    void setdateavis(QString);
    void setetat(QString);


    bool ajouter(Avis a);
    bool modifier (Avis a);
    bool supprimer(QString iddclient);
    QSqlQueryModel * afficher();
    QSqlQueryModel *rechercher(QString);
    QSqlQueryModel *tri();
    bool verif_nom(QString nom);
    bool verif_id(QString nom);

    private:
    QString num, idClient,etat, dateavis;


};

#endif // AVIS_H

