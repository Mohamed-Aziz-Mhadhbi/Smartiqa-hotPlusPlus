#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "chambre.h"
#include "servicech.h"

#include <QFile>
#include <QMessageBox>
#include <QDate>
#include <QTime>
#include <QTimer>
#include <QProgressBar>
#include <QStatusBar>
#include <QWidget>
#include <QString>
#include <QDebug>
#include <windows.h>

#include <QPrinter>
#include <QPrintDialog>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
ui->setupUi(this);

ui->tabchambre->setModel(tmpchambre.afficher());
ui->tabservice->setModel(tmpservice.afficher());
ui->cx_numch->setEnabled(1);

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::initchambre()
{
ui->cx_type->clear();
ui->cx_numch->clear();
}

void MainWindow::on_pb_ajouter_clicked()
{
    QString NUMCH,TYPE;
    NUMCH=ui->cx_numch->text();
    TYPE=ui->cx_type->text();


    chambre C(NUMCH,TYPE);


    if (C.verif_num_ch(C.get_numch())==true )
    {
        bool test=C.ajouter();

        if(test)
        {

            QFile file("C:\\Users\\Alya Bouguila\\Downloads\\chambre\\HistoriqueChambre.txt");
            if (!file.open(QIODevice::WriteOnly | QIODevice::Append |QIODevice::Text))
                return;
            QTextStream cout(&file);
            QString message2="\n Chambre  a été ajoutée sous le numero :"+NUMCH+" et sous le type : "+TYPE+"";
            cout << message2;


            initchambre();
            ui->tabchambre->setModel(tmpchambre.afficher());

        }

    }
}



void MainWindow::on_tabchambre_activated(const QModelIndex &index)
{
    QString val=ui->tabchambre->model()->data(index).toString();
    QSqlQuery qry ;

    qry.prepare("Select * from CHAMBRE where TYPE ='"+val+"' ");
    if (qry.exec())
    {
        while (qry.next())
        {

            ui->cx_numch->setDisabled(1);
            ui->cx_numch->setText(qry.value(0).toString());
            ui->cx_type->setText(qry.value(1).toString());
        }
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    QString NUMCH = ui->cx_numch->text();

    bool test=tmpchambre.supprimer(NUMCH);
    if(test)
    {    ui->tabchambre->setModel(tmpchambre.afficher());

        ui->cx_numch->setEnabled(1);

        initchambre();
    }
    else
        QMessageBox::critical(nullptr, QObject::tr("Supprimer Catégorie"),
                              QObject::tr("verifier l'id  !.\n"
                                          "Click Cancel to exit."), QMessageBox::Cancel);
}



void MainWindow::on_pushButton_4_clicked()
{
    QString NUMCH = ui->cx_numch->text();
    QString TYPE= ui->cx_type->text();
    chambre C(NUMCH,TYPE);
    if (C.verif_num_ch(C.get_numch())==true )
    {
    bool test=tmpchambre.modifier(C);
    if(test)
    {

        ui->tabchambre->setModel(tmpchambre.afficher());//refresh

        ui->cx_numch->setEnabled(1);

        initchambre();

    }
   }
}

void MainWindow::on_pushButton_3_clicked()
{
    QSqlQueryModel * model= new QSqlQueryModel();
    QSqlQuery q;
    q.prepare("select * from CHAMBRE where type like '"+ui->cx_recherche->text()+"' OR NUM_CH like '"+ui->cx_recherche->text()+"'  ");
    tmpchambre.rechercher(q) ;
    q.exec();
    model->setQuery(q);
    ui->tabchambre->setModel(tmpchambre.rechercher(q)) ;

}

void MainWindow::on_pushButton_clicked()
{
     ui->tabchambre->setModel(tmpchambre.afficher());
}

void MainWindow::on_radioButton_clicked()
{
    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("select * from chambre ORDER BY NUM_CH ");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Num_ch"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Type"));

    ui->tabchambre->setModel(model) ;

}

void MainWindow::on_radioButton_2_clicked()
{
    QSqlQueryModel * model= new QSqlQueryModel();

    model->setQuery("select * from chambre ORDER BY NUM_CH desc ");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Num_ch"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Type"));

    ui->tabchambre->setModel(model) ;
}

void MainWindow::on_radioButton_3_clicked()
{
    QSqlQueryModel * model= new QSqlQueryModel();
 model->setQuery("select * from chambre ORDER BY type ");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Num_ch"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Type"));

    ui->tabchambre->setModel(model) ;
}

void MainWindow::on_radioButton_4_clicked()
{

    QSqlQueryModel * model= new QSqlQueryModel();
model->setQuery("select * from chambre ORDER BY type desc");
    model->setHeaderData(0, Qt::Horizontal, QObject::tr("Num_ch"));
    model->setHeaderData(1, Qt::Horizontal, QObject::tr("Type"));

    ui->tabchambre->setModel(model) ;
}

void MainWindow::on_pushButton_6_clicked()
{
    QFile file ("C:\\Users\\Alya Bouguila\\Downloads\\chambre\\HistoriqueChambre.txt");
    if (!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::information(0,"info",file.errorString());
    }
    QTextStream in (&file);
    ui->historique_chambre->setText(in.readAll());
}

void MainWindow::on_pushButton_5_clicked()
{
     QPrinter printer;
    printer.setPrinterName("desierd printer name");
    QPrintDialog dialog(&printer,this);
    if(dialog.exec()== QDialog::Rejected) return;
    ui->historique_chambre->print(&printer);
}

void MainWindow::on_pushButton_7_clicked()
{
    QString searchString = ui->lineEdit_HR->text();
    QTextDocument *document = ui->historique_chambre->document();
    on_pushButton_6_clicked();
    bool found = false;

    document->undo();

    if (searchString.isEmpty()) {
        QMessageBox::information(this, tr("Empty Search Field"),
                                 tr("The search field is empty. "
                                    "Please enter a word and click Find."));
    } else {
        QTextCursor highlightCursor(document);
        QTextCursor cursor(document);

        cursor.beginEditBlock();


        QTextCharFormat plainFormat(highlightCursor.charFormat());
        QTextCharFormat colorFormat = plainFormat;
        colorFormat.setForeground(Qt::red);

        while (!highlightCursor.isNull() && !highlightCursor.atEnd()) {
            highlightCursor = document->find(searchString, highlightCursor,
                                             QTextDocument::FindWholeWords);

            if (!highlightCursor.isNull()) {
                found = true;
                highlightCursor.movePosition(QTextCursor::WordRight,
                                             QTextCursor::KeepAnchor);
                highlightCursor.mergeCharFormat(colorFormat);
            }
        }


        cursor.endEditBlock();

        if (found == false) {
            QMessageBox::information(this, tr("Word Not Found"),
                                     tr("Sorry, the word cannot be found."));
        }
    }
}

void MainWindow::on_pushButton_12_clicked()
{
    QFile file ("C:\\Users\\Alya Bouguila\\Downloads\\chambre\\HistoriqueSerciveChambre.txt");
    if (!file.open(QIODevice::ReadOnly))
    {
        QMessageBox::information(0,"info",file.errorString());
    }
    QTextStream in (&file);
    ui->historique_chambre->setText(in.readAll());
}

void MainWindow::on_pushButton_11_clicked()
{
    QPrinter printer;
   printer.setPrinterName("desierd printer name");
   QPrintDialog dialog(&printer,this);
   if(dialog.exec()== QDialog::Rejected) return;
   ui->historique_chambre->print(&printer);
}

void MainWindow::on_pb_ajouter_2_clicked()
{
    QString ID_SER_CH,type,ID_CH;
    ID_SER_CH=ui->lineEdit_idservch_2->text();
    ID_CH=ui->lineEdit_3->text();
    type=ui->comboBox->


     servicech S(ID_SER_CH ,type ,ID_CH);


    if (S.verif_IDSERCH(S.get_IDSERCH())==true )
    {
        bool test=S.ajouter();

        if(test)
        {

            QFile file("C:\\Users\\Alya Bouguila\\Downloads\\chambre\\HistoriqueChambre.txt");
            if (!file.open(QIODevice::WriteOnly | QIODevice::Append |QIODevice::Text))
                return;
            QTextStream cout(&file);
            QString message2="\n Service  a été ajoutée sous le numero :"+ID_SER_CH+" pour la chambre : "+ID_CH+",de type"+type+"";
            cout << message2;


            initchambre();
            ui->tabchambre->setModel(tmpchambre.afficher());

        }

    }
}
